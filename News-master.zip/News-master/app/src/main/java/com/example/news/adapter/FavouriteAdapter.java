package com.example.news.adapter;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.news.R;
import com.example.news.db.News;
import com.example.news.db.NewsRepositry;
import com.example.news.ui.web.WebViewActivity;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.drawable.ProgressBarDrawable;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.common.ResizeOptions;
import com.facebook.imagepipeline.common.RotationOptions;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;

import java.util.List;

public class FavouriteAdapter extends RecyclerView.Adapter<FavouriteAdapter.FavouriteViewHolder> {

    private Application application;
    private List<News> newsList;

    public FavouriteAdapter(Application application, List<News> newsList) {
        this.application = application;
        this.newsList = newsList;
    }

    public void setNewsList(List<News> newsList){
        this.newsList=newsList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public FavouriteViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.favourite_item,viewGroup,false);
        return new FavouriteViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull FavouriteViewHolder favouriteViewHolder, int i) {
              favouriteViewHolder.bindView(newsList.get(i));
    }

    @Override
    public int getItemCount() {
        return newsList.size();
    }

    public class FavouriteViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView sourceTV,titleTV,readTV,deleteTV;
        private SimpleDraweeView simpleDraweeView;
        private News news;
        private Context context;

        public FavouriteViewHolder(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();
            sourceTV = itemView.findViewById(R.id.source);
            titleTV = itemView.findViewById(R.id.title);
            readTV = itemView.findViewById(R.id.read);
            deleteTV = itemView.findViewById(R.id.delete);
            simpleDraweeView = itemView.findViewById(R.id.image);
            itemView.setOnClickListener(this);
            initListener();
        }


        private void bindView(News news){
            this.news=news;
            if (news!=null){
                sourceTV.setText(news.getSource());
                titleTV.setText(news.getTitle());
                try {
                    Uri uri = Uri.parse(news.getImageURL());
                    if (uri!=null){
                        bindImage(uri);
                    }

                }catch (Exception e){

                }


            }else {
                sourceTV.setText("null");
                titleTV.setText("null");
            }

        }


        private void bindImage(Uri uri){

            ImageRequest imageRequest = ImageRequestBuilder.newBuilderWithSource(uri)
                    .setResizeOptions(new ResizeOptions(80,80))
                    .setRotationOptions(RotationOptions.autoRotate())
                    .build();

            simpleDraweeView.setController(Fresco.newDraweeControllerBuilder()
                    .setOldController(simpleDraweeView.getController())
                    .setImageRequest(imageRequest)
                    .build());

            simpleDraweeView.getHierarchy().setProgressBarImage(new ProgressBarDrawable());
        }

        private void initListener(){
            readTV.setOnClickListener(this);
            deleteTV.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {

           switch(v.getId()){
               case R.id.read:
                   Intent intent = new Intent(context, WebViewActivity.class);
                   Bundle bundle = new Bundle();
                   bundle.putString(WebViewActivity.KEY,news.getSourceURL());
                   intent.putExtra(WebViewActivity.KEY,bundle);
                   context.startActivity(intent);
                   return;

               case R.id.delete:
                   NewsRepositry newsRepositry = new NewsRepositry(application);
                   newsRepositry.delete(news);
                   return;
                   default:
                       return;

           }
        }
    }
}
