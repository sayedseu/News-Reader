package com.example.news.data;

public class DataManager extends RetrofitHelper{

}
