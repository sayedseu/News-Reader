package com.example.news.data;

import android.util.Log;

import com.example.news.model.news.ServerResponse;
import com.example.news.retrofit.ApiService;
import com.example.news.retrofit.ResponseCallback;
import com.example.news.retrofit.RetrofitApiClient;
import com.example.news.retrofit.RetrofitApiInterface;
import com.facebook.common.internal.ImmutableMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class RetrofitHelper implements ApiService {

    private RetrofitApiInterface retrofitApiInterface;


    public RetrofitHelper() {
        retrofitApiInterface= RetrofitApiClient.getRetrofitClient()
                .create(RetrofitApiInterface.class);

    }


    @Override
    public void loadHeadlines(final ResponseCallback<ServerResponse> callback) {
       retrofitApiInterface.getHeadlines().enqueue(new Callback<ServerResponse>() {
           @Override
           public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
               if (response.isSuccessful()){
                   if (response.body()!=null){
                       callback.onSucess(response.body());
                   }
               }else {
                   callback.onError(new Exception(response.message()));
               }
           }

           @Override
           public void onFailure(Call<ServerResponse> call, Throwable t) {
               callback.onError(t);
           }
       });
    }

    @Override
    public void loadGeneral(final ResponseCallback<ServerResponse> callback) {

        retrofitApiInterface.getGenerals().enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful()){
                    if (response.body()!=null){
                        callback.onSucess(response.body());
                    }
                }else {
                    callback.onError(new Exception(response.message()));
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                callback.onError(t);
            }
        });

    }

    @Override
    public void loadEntertainment(final ResponseCallback<ServerResponse> callback) {

        retrofitApiInterface.getEntertainments().enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful()){
                    if (response.body()!=null){
                        callback.onSucess(response.body());
                    }
                }else {
                    callback.onError(new Exception(response.message()));
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                callback.onError(t);
            }
        });

    }

    @Override
    public void loadBusiness(final ResponseCallback<ServerResponse> callback) {

        retrofitApiInterface.getBusiness().enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful()){
                    if (response.body()!=null){
                        callback.onSucess(response.body());
                    }
                }else {
                    callback.onError(new Exception(response.message()));
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                callback.onError(t);
            }
        });

    }

    @Override
    public void loadSports(final ResponseCallback<ServerResponse> callback) {

        retrofitApiInterface.getSports().enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful()){
                    if (response.body()!=null){
                        callback.onSucess(response.body());
                    }
                }else {
                    callback.onError(new Exception(response.message()));
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                callback.onError(t);
            }
        });

    }

    @Override
    public void loadScience(final ResponseCallback<ServerResponse> callback) {

        retrofitApiInterface.getSciencs().enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful()){
                    if (response.body()!=null){
                        callback.onSucess(response.body());
                    }
                }else {
                    callback.onError(new Exception(response.message()));
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                callback.onError(t);
            }
        });

    }

    @Override
    public void loadHealth(final ResponseCallback<ServerResponse> callback) {

        retrofitApiInterface.getHealths().enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful()){
                    if (response.body()!=null){
                        callback.onSucess(response.body());
                    }
                }else {
                    callback.onError(new Exception(response.message()));
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                callback.onError(t);
            }
        });

    }

    @Override
    public void loadTechnology(final ResponseCallback<ServerResponse> callback) {

        retrofitApiInterface.getTechnologys().enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful()){
                    if (response.body()!=null){
                        callback.onSucess(response.body());
                    }
                }else {
                    callback.onError(new Exception(response.message()));
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                callback.onError(t);
            }
        });

    }

    @Override
    public void loadSource(final ResponseCallback<com.example.news.model.source.ServerResponse> callback) {
        retrofitApiInterface.getSource().enqueue(new Callback<com.example.news.model.source.ServerResponse>() {
            @Override
            public void onResponse(Call<com.example.news.model.source.ServerResponse> call, Response<com.example.news.model.source.ServerResponse> response) {
                if (response.isSuccessful()){
                    if (response.body()!=null){
                        callback.onSucess(response.body());
                    }
                }else {
                    callback.onError(new Exception(response.message()));
                }
            }

            @Override
            public void onFailure(Call<com.example.news.model.source.ServerResponse> call, Throwable t) {
                 callback.onError(t);
            }
        });
    }

    @Override
    public void loadBySearching(final ResponseCallback<ServerResponse> callback, String query) {

         String q ="q";
         String k="apiKey" ;
         String key = "ff084860c50a4968948d1861ad035b81";


        retrofitApiInterface.getResultBySearching(ImmutableMap.of(k,key,q,"('"+query+"')")).enqueue(new Callback<ServerResponse>() {
            @Override
            public void onResponse(Call<ServerResponse> call, Response<ServerResponse> response) {
                if (response.isSuccessful()){
                    if (response.body()!=null){
                        callback.onSucess(response.body());
                    }
                }else {
                    Log.d("RRRRRRRRRRRRRRRRRRRR",response.message());
                    callback.onError(new Exception(response.message()));
                }
            }

            @Override
            public void onFailure(Call<ServerResponse> call, Throwable t) {
                callback.onError(t);
                Log.d("RRRRRRRRRRRRRRRRRRRR",t.toString());
            }
        });

    }
}
