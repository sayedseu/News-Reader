package com.example.news.ui.search;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.example.news.data.DataManager;
import com.example.news.model.news.Article;
import com.example.news.model.news.ServerResponse;
import com.example.news.retrofit.ResponseCallback;

import java.util.List;

public class SearchViewModel extends ViewModel {

    public LiveData<List<Article>> getNews(String query) {

        final MutableLiveData<List<Article>> liveData = new MutableLiveData<>();

        DataManager dataManager =new DataManager();
        dataManager.loadBySearching(new ResponseCallback<ServerResponse>() {
            @Override
            public void onSucess(ServerResponse data) {
                liveData.setValue(data.getArticles());
            }

            @Override
            public void onError(Throwable throwable) {
             liveData.setValue(null);
            }
        },query);


        return liveData;
    }
}
