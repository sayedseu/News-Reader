package com.example.news.ui.source;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.example.news.data.DataManager;
import com.example.news.model.source.ServerResponse;
import com.example.news.model.source.Source;
import com.example.news.retrofit.ResponseCallback;


import java.util.List;

public class SourceViewModel extends ViewModel {

    public LiveData<List<Source>> getNews() {

        final MutableLiveData<List<Source>> liveData = new MutableLiveData<>();

        DataManager dataManager =new DataManager();
        dataManager.loadSource(new ResponseCallback<ServerResponse>() {
            @Override
            public void onSucess(ServerResponse data) {
                liveData.setValue(data.getSources());
            }

            @Override
            public void onError(Throwable throwable) {
               liveData.setValue(null);
            }
        });

        return liveData;
    }
}
