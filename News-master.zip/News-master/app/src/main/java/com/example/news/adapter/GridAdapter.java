package com.example.news.adapter;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.news.R;
import com.example.news.model.source.Source;
import com.example.news.ui.web.WebViewActivity;

import java.util.List;

public class GridAdapter extends RecyclerView.Adapter<GridAdapter.GridViewHolder> {

    private List<Source> sourceList;

    public GridAdapter(List<Source> sourceList) {
        this.sourceList = sourceList;
    }

    @NonNull
    @Override
    public GridViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.single_source,viewGroup,false);
        return new GridViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull GridViewHolder gridViewHolder, int i) {

      gridViewHolder.boundView(sourceList.get(i));
    }

    @Override
    public int getItemCount() {
        return sourceList.size();
    }

    public static class GridViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView title;
        private Source source;
        private Context context;

        private GridViewHolder(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();
            title=itemView.findViewById(R.id.title);
            itemView.setOnClickListener(this);
        }

        private void boundView(Source source){
            this.source=source;
            title.setText(source.getName());
        }


        @Override
        public void onClick(View v) {
            Intent intent = new Intent(context, WebViewActivity.class);
            Bundle bundle = new Bundle();
            bundle.putString(WebViewActivity.KEY,source.getUrl());
            intent.putExtra(WebViewActivity.KEY,bundle);
            context.startActivity(intent);

        }
    }
}
