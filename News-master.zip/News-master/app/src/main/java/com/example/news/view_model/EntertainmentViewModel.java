package com.example.news.view_model;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.example.news.data.DataManager;
import com.example.news.model.news.Article;
import com.example.news.model.news.ServerResponse;
import com.example.news.retrofit.ResponseCallback;

import java.util.List;

public class EntertainmentViewModel extends ViewModel {
    public LiveData<List<Article>> getNews() {

        final MutableLiveData<List<Article>> liveData = new MutableLiveData<>();

        DataManager dataManager =new DataManager();
        dataManager.loadEntertainment(new ResponseCallback<ServerResponse>() {
            @Override
            public void onSucess(ServerResponse data) {
                liveData.setValue(data.getArticles());
            }

            @Override
            public void onError(Throwable throwable) {

            }
        });

        return liveData;
    }

}
