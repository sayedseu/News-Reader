package com.example.news.db;

import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;

import java.util.List;

public class NewsRepositry {

    private NewsDao newsDao;
    private LiveData<List<News>> newsList;

    public NewsRepositry (Application application){
        NewsDatabase newsDatabase =  NewsDatabase.getInstance(application);
        this.newsDao=newsDatabase.newsDao();
        newsList = newsDao.getAllNews();
    }

    public void insert(News news){
       new InsertAsyncTask(newsDao).execute(news);
    }

    public void delete(News news){
       new  DeleteAsyncTask(newsDao).execute(news);
    }

    public LiveData<List<News>> getNewsList(){
        return newsList;
    }

    private static class InsertAsyncTask extends AsyncTask<News,Void,Void>{

        private NewsDao newsDao;

        public InsertAsyncTask(NewsDao newsDao) {
            this.newsDao = newsDao;
        }

        @Override
        protected Void doInBackground(News... news) {
            newsDao.insert(news[0]);
            return null;
        }
    }

    private static class DeleteAsyncTask extends AsyncTask<News,Void,Void>{

        private NewsDao newsDao;

        public DeleteAsyncTask(NewsDao newsDao) {
            this.newsDao = newsDao;
        }

        @Override
        protected Void doInBackground(News... news) {
            newsDao.delete(news[0]);
            return null;
        }
    }
}
