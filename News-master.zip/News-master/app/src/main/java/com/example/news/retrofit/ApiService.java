package com.example.news.retrofit;

import com.example.news.model.news.ServerResponse;

public interface ApiService {

    void loadHeadlines(ResponseCallback<ServerResponse> callback);
    void loadGeneral(ResponseCallback<ServerResponse> callback);
    void loadEntertainment(ResponseCallback<ServerResponse> callback);
    void loadBusiness(ResponseCallback<ServerResponse> callback);
    void loadSports(ResponseCallback<ServerResponse> callback);
    void loadScience(ResponseCallback<ServerResponse> callback);
    void loadHealth(ResponseCallback<ServerResponse> callback);
    void loadTechnology(ResponseCallback<ServerResponse> callback);
    void loadSource(ResponseCallback<com.example.news.model.source.ServerResponse> callback);
    void loadBySearching(ResponseCallback<ServerResponse> callback,String string);
}
