package com.example.news.ui.headline;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.news.R;
import com.example.news.adapter.MyAdapter;
import com.example.news.model.news.Article;
import com.github.ybq.android.spinkit.SpinKitView;
import com.github.ybq.android.spinkit.style.Wave;

import java.util.List;

public class HeadlineFragment extends Fragment {

    private HeadlineViewModel mViewModel;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private SpinKitView spinKitView;

    public static HeadlineFragment newInstance() {
        return new HeadlineFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view =  inflater.inflate(R.layout.headline_fragment, container, false);
        initView(view,container);
        return view;
    }

    private void initView(View view,ViewGroup container){
        spinKitView = view.findViewById(R.id.spin_kit);
        Wave wave = new Wave();
        spinKitView.setIndeterminateDrawable(wave);
        spinKitView.setVisibility(View.VISIBLE);
        recyclerView = view.findViewById(R.id.recID);
        layoutManager = new LinearLayoutManager(container.getContext());
        ((LinearLayoutManager) layoutManager).setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(HeadlineViewModel.class);
        mViewModel.getNews().observe(this, new Observer<List<Article>>() {
            @Override
            public void onChanged(@Nullable List<Article> articles) {
                spinKitView.setVisibility(View.INVISIBLE);
                MyAdapter myAdapter = new MyAdapter(articles,getActivity().getApplication());
                recyclerView.setAdapter(myAdapter);
            }
        });
    }

}
