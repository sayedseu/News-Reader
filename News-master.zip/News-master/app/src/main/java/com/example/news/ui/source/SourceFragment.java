package com.example.news.ui.source;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.news.R;
import com.example.news.adapter.GridAdapter;
import com.example.news.model.source.Source;
import com.github.ybq.android.spinkit.SpinKitView;
import com.github.ybq.android.spinkit.style.Wave;

import java.util.List;

public class SourceFragment extends Fragment {

    private SourceViewModel mViewModel;
    private RecyclerView recyclerView ;
    private RecyclerView.LayoutManager layoutManager;
    private SpinKitView spinKitView;

    public static SourceFragment newInstance() {
        return new SourceFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.source_fragment, container, false);

       initProgress(view);

        recyclerView=view.findViewById(R.id.recID);
        int currentOrientation = getResources().getConfiguration().orientation;
        if (currentOrientation == Configuration.ORIENTATION_LANDSCAPE) {
            layoutManager=new GridLayoutManager(container.getContext(),3);
            ((LinearLayoutManager) layoutManager).setOrientation(LinearLayoutManager.VERTICAL);
        }
        else {
            layoutManager=new GridLayoutManager(container.getContext(),2);
            ((LinearLayoutManager) layoutManager).setOrientation(LinearLayoutManager.VERTICAL);
        }

        recyclerView.setLayoutManager(layoutManager);
        return view;
    }

    void initProgress(View view){
        spinKitView = view.findViewById(R.id.spin_kit);
        Wave wave = new Wave();
        spinKitView.setIndeterminateDrawable(wave);
        spinKitView.setVisibility(View.VISIBLE);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(SourceViewModel.class);
        mViewModel.getNews().observe(this, new Observer<List<Source>>() {
            @Override
            public void onChanged(@Nullable List<Source> sources) {
                if (!sources.isEmpty()){
                    spinKitView.setVisibility(View.GONE);
                    GridAdapter gridAdapter = new GridAdapter(sources);
                    recyclerView.setAdapter(gridAdapter);
                }

            }
        });

    }

}
