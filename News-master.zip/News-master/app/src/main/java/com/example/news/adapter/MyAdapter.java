package com.example.news.adapter;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.news.R;
import com.example.news.db.News;
import com.example.news.db.NewsRepositry;
import com.example.news.model.news.Article;
import com.example.news.ui.search.SearchActivity;
import com.example.news.ui.web.WebViewActivity;
import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.drawable.ProgressBarDrawable;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.common.ResizeOptions;
import com.facebook.imagepipeline.common.RotationOptions;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;

import java.util.List;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {

    private List<Article> mArticleList;
    private Application application;

    public MyAdapter(List<Article> mArticleList,Application application) {
        this.mArticleList = mArticleList;
        this.application = application;
    }

    public MyAdapter(Application application) {
        this.application = application;
    }

    public void setmArticleList(List<Article> articleList){
        this.mArticleList = articleList;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext())
                .inflate(R.layout.single_item,viewGroup,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.bindView(mArticleList.get(i));

    }

    @Override
    public int getItemCount() {
        return mArticleList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private TextView titleTV,sourceTV,timeTV;
        private SimpleDraweeView simpleDraweeView;
        private TextView readTV,bookmarksTV;
        private Article article;
        private Context context;


        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            context = itemView.getContext();
            timeTV = itemView.findViewById(R.id.time);
            titleTV = itemView.findViewById(R.id.title);
            sourceTV = itemView.findViewById(R.id.source);
            simpleDraweeView=itemView.findViewById(R.id.image);
            readTV=itemView.findViewById(R.id.read);
            bookmarksTV=itemView.findViewById(R.id.bookmarks);
            itemView.setOnClickListener(this);
            initListener();

        }

        private void bindView(Article article){
            this.article=article;
            if (article!=null){
                titleTV.setText(article.getTitle());
                timeTV.setText(article.getPublishedAt());
                sourceTV.setText(article.getSource().getName());
                try {
                    Uri uri = Uri.parse(article.getUrlToImage());
                    if (uri!=null){
                        bindImage(uri);
                    }

                }catch (Exception e){

                }


            }else {
                titleTV.setText("null");
                timeTV.setText("null");
            }

        }

        private void bindImage(Uri uri){

            ImageRequest imageRequest = ImageRequestBuilder.newBuilderWithSource(uri)
                    .setResizeOptions(new ResizeOptions(350,350))
                    .setRotationOptions(RotationOptions.autoRotate())
                    .build();

            simpleDraweeView.setController(Fresco.newDraweeControllerBuilder()
                    .setOldController(simpleDraweeView.getController())
                    .setImageRequest(imageRequest)
                    .build());

            simpleDraweeView.getHierarchy().setProgressBarImage(new ProgressBarDrawable());
        }

        private void initListener(){
            readTV.setOnClickListener(this);
            bookmarksTV.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.read:
                    Intent intent = new Intent(context, WebViewActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putString(WebViewActivity.KEY,article.getUrl());
                    intent.putExtra(WebViewActivity.KEY,bundle);
                    context.startActivity(intent);
                    return;

                case R.id.bookmarks:
                    NewsRepositry newsRepositry = new NewsRepositry(application);
                    News news = new News(
                            article.getTitle(),
                            article.getSource().getName(),
                            article.getUrl(),
                            article.getUrlToImage());
                    newsRepositry.insert(news);
                    return;
                    default:
                        return;
            }

        }
    }
}
