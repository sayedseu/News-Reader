package com.example.news.retrofit;

import com.example.news.model.news.ServerResponse;

import java.util.Map;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.QueryMap;

public interface RetrofitApiInterface {

  @GET("/v2/top-headlines?country=us&apiKey=ff084860c50a4968948d1861ad035b81")
    Call<ServerResponse> getHeadlines();
  @GET("/v2/top-headlines?category=entertainment&apiKey=ff084860c50a4968948d1861ad035b81")
    Call<ServerResponse> getEntertainments();
  @GET("/v2/top-headlines?category=general&apiKey=ff084860c50a4968948d1861ad035b81")
    Call<ServerResponse> getGenerals();
  @GET("/v2/top-headlines?category=business&apiKey=ff084860c50a4968948d1861ad035b81")
    Call<ServerResponse> getBusiness();
  @GET("/v2/top-headlines?category=health&apiKey=ff084860c50a4968948d1861ad035b81")
    Call<ServerResponse> getHealths();
  @GET("/v2/top-headlines?category=science&apiKey=ff084860c50a4968948d1861ad035b81")
    Call<ServerResponse> getSciencs();
  @GET("/v2/top-headlines?category=sports&apiKey=ff084860c50a4968948d1861ad035b81")
    Call<ServerResponse> getSports();
  @GET("/v2/top-headlines?category=technology&apiKey=ff084860c50a4968948d1861ad035b81")
    Call<ServerResponse> getTechnologys();
  @GET("/v2/everything")
    Call<ServerResponse> getResultBySearching(@QueryMap Map<String,String> filters);
  @GET("/v2/sources?apiKey=ff084860c50a4968948d1861ad035b81")
    Call<com.example.news.model.source.ServerResponse> getSource();
}
