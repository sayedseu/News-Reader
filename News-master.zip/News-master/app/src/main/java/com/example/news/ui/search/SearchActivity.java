package com.example.news.ui.search;

import android.app.SearchManager;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import com.example.news.R;
import com.example.news.adapter.MyAdapter;
import com.example.news.model.news.Article;
import com.example.news.ui.search.SearchViewModel;
import com.github.ybq.android.spinkit.SpinKitView;
import com.github.ybq.android.spinkit.style.Wave;

import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private ViewModel viewModel;
    private TextView textView;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private SpinKitView spinKitView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        String query=null;
        String toolText=null;
        Intent intent = getIntent();
        if (Intent.ACTION_SEARCH.equals(intent.getAction())) {
            String s = intent.getStringExtra(SearchManager.QUERY);
            toolText=s;
            String[] arr = s.split(" ");
            StringBuilder stringBuilder = new StringBuilder();
            for (int i=0;i<arr.length;i++){
                stringBuilder.append(arr[i]);
                if (i<arr.length-1){
                    stringBuilder.append("+");
                }


            }
            query=stringBuilder.toString();

        }

        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle(toolText);
        setSupportActionBar(toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setDisplayHomeAsUpEnabled(true);

        textView=findViewById(R.id.textView);
        recyclerView = findViewById(R.id.recID);
        spinKitView = findViewById(R.id.spin_kit);
        Wave wave = new Wave();
        spinKitView.setIndeterminateDrawable(wave);
        spinKitView.setVisibility(View.VISIBLE);
        layoutManager = new LinearLayoutManager(this);
        ((LinearLayoutManager) layoutManager).setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

        final MyAdapter myAdapter = new MyAdapter(this.getApplication());
        viewModel = ViewModelProviders.of(this).get(SearchViewModel.class);
        ((SearchViewModel) viewModel).getNews(query).observe(this, new Observer<List<Article>>() {
            @Override

            public void onChanged(@Nullable List<Article> articles) {
                if (articles.isEmpty()){
                    Log.d("AAAAAAAAAAAAA","in");
                    spinKitView.setVisibility(View.INVISIBLE);
                    textView.setVisibility(View.VISIBLE);
                }else{
                    spinKitView.setVisibility(View.INVISIBLE);
                    myAdapter.setmArticleList(articles);
                    recyclerView.setAdapter(myAdapter);
                }

            }
        });

    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return true;
    }
}
