package com.example.news.ui.favorite;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import com.example.news.db.News;
import com.example.news.db.NewsRepositry;

import java.util.List;

public class FavoriteViewModel extends AndroidViewModel {

    private LiveData<List<News>> newsList;

    public FavoriteViewModel(@NonNull Application application) {
        super(application);
        NewsRepositry newsRepositry = new NewsRepositry(application);
        newsList = newsRepositry.getNewsList();
    }

    public LiveData<List<News>> getNewsList(){
        return newsList;
    }
}
