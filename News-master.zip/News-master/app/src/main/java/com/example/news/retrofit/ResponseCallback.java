package com.example.news.retrofit;

public interface ResponseCallback<T> {

    void onSucess(T data);
    void onError(Throwable throwable);
}
