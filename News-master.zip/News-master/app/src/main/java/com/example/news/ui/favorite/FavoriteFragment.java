package com.example.news.ui.favorite;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.news.R;
import com.example.news.adapter.FavouriteAdapter;
import com.example.news.adapter.MyAdapter;
import com.example.news.db.News;
import com.github.ybq.android.spinkit.SpinKitView;
import com.github.ybq.android.spinkit.style.Wave;

import java.util.List;

public class FavoriteFragment extends Fragment {

    private FavoriteViewModel mViewModel;
    private RecyclerView recyclerView;
    private RecyclerView.LayoutManager layoutManager;
    private SpinKitView spinKitView;

    public static FavoriteFragment newInstance() {
        return new FavoriteFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.favorite_fragment, container, false);
        initView(view,container);
        return view;
    }

    private void initView(View view,ViewGroup container){
        spinKitView = view.findViewById(R.id.spin_kit);
        Wave wave = new Wave();
        spinKitView.setIndeterminateDrawable(wave);
        spinKitView.setVisibility(View.VISIBLE);
        recyclerView = view.findViewById(R.id.recID);
        layoutManager = new LinearLayoutManager(container.getContext());
        ((LinearLayoutManager) layoutManager).setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(layoutManager);

    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = ViewModelProviders.of(this).get(FavoriteViewModel.class);
        mViewModel.getNewsList().observe(this, new Observer<List<News>>() {
            @Override
            public void onChanged(@Nullable List<News> news) {



                spinKitView.setVisibility(View.INVISIBLE);
                FavouriteAdapter favouriteAdapter = new FavouriteAdapter(getActivity().getApplication(),news);
                favouriteAdapter.setNewsList(news);
                recyclerView.setAdapter(favouriteAdapter);
            }
        });
    }

}
